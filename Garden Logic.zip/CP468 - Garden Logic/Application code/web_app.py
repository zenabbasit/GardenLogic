import csv
from flask import Flask, render_template, request, redirect, url_for
from Garden_functions import filter_garden_data, choosing_plants


app = Flask(__name__)

# Dictionary containing information about plant hardiness zones in Ontario
zone_info = {
    "0b": {
        "description": "Zone 0b is characterized by extremely cold winters with average annual extreme minimum temperatures of -45°F or colder.",
    },
    "1b": {
        "description": "Zone 1b features cold winters with average annual extreme minimum temperatures of -40°F to -45°F.",
    },
    "2a": {
        "description": "Zone 2a experiences cold winters with average annual extreme minimum temperatures of -35°F to -40°F."
    },
    "2b": {
        "description": "Zone 2b has cool winters with average annual extreme minimum temperatures of -30°F to -35°F.",
    },
    "3a": {
        "description": "Zone 3a has moderately cold winters with average annual extreme minimum temperatures of -25°F to -30°F.",
    },
    "3b": {
        "description": "Zone 3b experiences cool winters with average annual extreme minimum temperatures of -20°F to -25°F.",
    },
    "4a": {
        "description": "Zone 4a has mild winters with average annual extreme minimum temperatures of -15°F to -20°F.",
    },
    "4b": {
        "description": "Zone 4b features relatively warm winters with average annual extreme minimum temperatures of -10°F to -15°F.",
    },
    "5a": {
        "description": "Zone 5a experiences cool winters with average annual extreme minimum temperatures of -5°F to -10°F.",
    },
    "5b": {
        "description": "Zone 5b has cold winters with average annual extreme minimum temperatures of 0°F to -5°F.",
    },
    "6a": {
        "description": "Zone 6a has moderately cold winters with average annual extreme minimum temperatures of 5°F to 0°F.",
    },
    "6b": {
        "description": "Zone 6b experiences cool winters with average annual extreme minimum temperatures of 10°F to 5°F.",
    },
    "7a": {
        "description": "Zone 7a has mild winters with average annual extreme minimum temperatures of 15°F to 10°F.",
    }
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/find_zone', methods=['POST'])
def find_zone():
    if request.method == 'POST':
        # Retrieve the city name entered by the user from the form
        city_name = request.form['city_name']
        print("City Name:", city_name)  # Add this line to check if city name is properly received

        # Load the CSV file containing city-zone mappings
        with open('Plant Hardiness Zones - Ontario (by city).csv', 'r') as csvfile:
            csv_reader = csv.reader(csvfile)
            cities_zones = list(csv_reader)

            start = 0
            end = len(cities_zones) - 1
            city_name_formatted = city_name.replace(" ", "")
            city_name_formatted.lower()
            print(city_name_formatted)
            zone = None

            # Binary search to find the zone for the given city
            while start <= end:
                mid = (start + end) // 2
                current_city_name = cities_zones[mid][0].replace(" ", "").lower()
                print(current_city_name)
                if current_city_name == city_name_formatted:
                    zone = cities_zones[mid][1]
                    break
                elif current_city_name < city_name_formatted:
                    start = mid + 1
                else:
                    end = mid - 1

            print("Zone1:", zone)  # Add this line to check if zone is properly retrieved

            # Prepare data to be passed to the result template
            zone_info_data = {
                "zone": zone,
                "description": zone_info.get(zone, {}).get("description", "Description not available")
            }

            # Render the result template with the zone information
            return render_template('result_zone.html', zone_info=zone_info_data, zone=zone)

@app.route('/garden_input', methods=['POST'])
def garden_input():
    # Retrieve the zone value from the URL parameters
    zone = request.form.get('zone')
    print("Zone2:", zone)

    # Render the garden_input.html template and pass the zone value to the template
    return render_template('garden_input.html', zone=zone)

@app.route('/garden_results', methods=['POST'])
def garden_results():
    # Retrive all the values from the users inputs
    # types and seasons must be lists
    types = request.form.getlist('plant_types')
    light = request.form.get('sunlight')
    seasons = request.form.getlist('seasons')
    soil = request.form.get('soil_type')
    # zone = request.form.get('zone')
    zone = '5a'  # manually set the zone until zone request is resolved
    print('zone in garden_results() is: ', zone)

    plants_list = filter_garden_data(types, light, zone, seasons, soil)
    return render_template('garden_results.html', plants=plants_list)

@app.route('/soil_guide')
def soil_guide():
    return render_template('soil_guide.html')

@app.route('/customized_garden', methods=['POST'])
def customized_garden():
    selected_plants = request.form.getlist('selected_plants[]')
    dimensions = request.form.getlist('dimensions[]')
    length = request.form.get('length')
    width = request.form.get('width')
    print('Selected plants:', selected_plants)
    print('Dimensions:', dimensions)
    
    # Initialize an empty list to store selected plants with their dimensions
    selected_plants_with_dimensions = []
    
    # Iterate over selected plants and their dimensions
    for plant, dimension in zip(selected_plants, dimensions):
        # Check if the current plant is selected
        if plant in selected_plants:
            # Split the dimension string into length and width
            dimension_values = dimension.split(',')
            # Convert length and width to integers
            length_value = float(dimension_values[0])
            width_value = float(dimension_values[1])
            # Append the plant name along with its dimensions to the list
            plants = [plant, length_value, width_value]
            selected_plants_with_dimensions.append(plants)
    
    print('Selected plants with dimensions:', selected_plants_with_dimensions)
    
    # pass to the function to select
    chosen_plants = choosing_plants(selected_plants_with_dimensions, length, width)

    # Pass the selected plants with their dimensions to the template
    return render_template('customized_garden.html', plants=chosen_plants)

if __name__ == '__main__':
    app.run(debug=True)