# Imports
import csv 
import pandas as pd
import random
import numpy as np

"""
The function below filters the main database according to the users requests.
This includes: plant types, zone, light available, soil type, and preffered growing season. 
"""
def filter_garden_data(plant_types, sun_light, zone, seasons, soil_type):
    print('plant types: ', plant_types)
    print('sun_light: ', sun_light)
    print('zone: ', zone)
    print('season: ', seasons)
    print('soil: ', soil_type)

    df = pd.read_csv('garden_data.csv')

    # Initialize an empty DataFrame to store filtered results
    plants = pd.DataFrame(columns=df.columns)  
    
    # Filter by each plant type and concatenate the results
    for plant_type in plant_types:
        plants_for_type = df[df['Plants type'].str.contains(plant_type, case=False)]
        plants = pd.concat([plants, plants_for_type], ignore_index=True)

    # Filter by sun light available
    
    #plants = plants[plants['Sun light'] == sun_light]

    # Filter by zone
    plants = plants[plants.apply(lambda row: check_zone_in_range(zone, row['Hardiness Zone']), axis=1)]

    # Filter by preffered season
    plants = plants[plants['Growing season'].isin(seasons)]

    # Filter by sun light available
    plants = plants[plants['Sun light'].isin([sun_light, 'Full Sun/Partial Shade'])]

    print('filtered plants: ', plants)

    # Filter by soil types
    # plants = plants[plants.apply(lambda row: check_soil_types(row['Soil type'], soil_type), axis=1)]

    # Convert the filterred dataframe into an array that holds the name and the area in m^2 of the garden 
    select_cols = plants[['Plant Name', 'Length', 'Width']]

    plant_data = select_cols.values.tolist()

    # Iterate over the list and construct arrays with [name, width, length] components
    plant_arrays = [[row[0], row[2], row[1]] for row in plant_data]

    # Convert the list of arrays to a 2D NumPy array
    plants_array = np.array(plant_arrays)
    print('from function: ', plant_arrays)
    return(plants_array)

"""
A helper method to check if a given zone is within a plants hardiness zones.
"""
def check_zone_in_range(user_zone, plant_zone_range):
    # Extract the minimum and maximum zones from the plant's zone range
    min_zone, max_zone = plant_zone_range.split('-')
    
    # Compare the user's input zone directly to the plant's zone range
    return min_zone <= (user_zone) <= max_zone

"""
A helper method to "process" the soil type data and check for matching types.
"""
def check_soil_types(plant_soil_types, user_soil_types):
    # Split the plant's soil types and convert to a set
    plant_soil_types = set(plant_soil_types.split('/'))

    # Convert the user's soil types to a set
    user_soil_types = set(user_soil_types)

    # Check if any of the plant's soil types match with the user's soil types
    if plant_soil_types.intersection(user_soil_types):
        return True
    else:
        return False
    
"""
The following function implements the main algorithm of the system.
"""
def choosing_plants(input, length, width):
    a_s = float(length) * float(width)
    input = sorted(input, key=lambda x: x[1])
    print('sorted plants: ', input)
    plants = []
    i = 0
    while i < len(input):
        current_plant = input[i]
        current_availble_space = a_s - float(input[i][1]) * float(input[i][2])
        if current_availble_space >= 0:
            update_plants_list(plants, input[i][0])
            a_s = current_availble_space
        
        i += 1

        if i == len(input) and a_s >= float(input[0][1])*float(input[0][2]):
            i = 0

    return plants

"""
A helper method to check if plant is already in the list, if so, update the count, if not, append.
"""
def update_plants_list(plants, plant_name):
    found = False
    for plant in plants:
        if plant[0] == plant_name:
            plant[1] += 1
            found = True
            break
    if not found:
        plants.append([plant_name, 1])


